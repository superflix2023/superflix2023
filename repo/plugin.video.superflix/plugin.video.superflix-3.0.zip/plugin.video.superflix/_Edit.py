import xbmcaddon

MainBase = 'aHR0cHM6Ly9naXRsYWIuY29tL3N1cGVyZmxpeDIwMTkvc3VwZXJmbGl4L3Jhdy9tYXN0ZXIvQWRkb24lMjBzdXBlcmZsaXglMjBCYXNl'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.superflix')